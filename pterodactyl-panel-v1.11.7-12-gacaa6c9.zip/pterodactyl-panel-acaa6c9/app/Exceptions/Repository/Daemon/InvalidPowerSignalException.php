<?php

namespace Pterodactyl\Exceptions\Repository\Daemon;

use Pterodactyl\Exceptions\Repository\RepositoryException;

class InvalidPowerSignalException extends RepositoryException
{
}
